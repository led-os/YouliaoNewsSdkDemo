package com.bytedance.dpdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.TTAdManagerHolder;
import com.bytedance.sdk.dp.DPSdk;

/**
 * Create by hanweiwei on 2020-03-10.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String ver = getString(R.string.main_sdk_version_tip, DPSdk.getVersion());
        TextView tv = findViewById(R.id.tv_version);
        tv.setText(ver);


        findViewById(R.id.btn_draw).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(DrawVideoActivity.class);
            }
        });

        findViewById(R.id.btn_grid).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(GridActivity.class);
            }
        });

        findViewById(R.id.btn_news).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(NewsActivity.class);
            }
        });

        TTAdManagerHolder.get().requestPermissionIfNecessary(this);
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}
