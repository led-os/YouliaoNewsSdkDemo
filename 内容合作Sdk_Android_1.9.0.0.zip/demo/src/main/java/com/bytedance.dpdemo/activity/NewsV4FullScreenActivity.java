package com.bytedance.dpdemo.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetNewsParams;
import com.bytedance.sdk.dp.IDPNewsListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.Map;

/**
 * 全屏多频道新闻列表样式展示
 * Create by zhangxiaomin on 2020-06-12.
 */
public class NewsV4FullScreenActivity extends AppCompatActivity {
    public static final String TAG = NewsV4FullScreenActivity.class.getSimpleName();
    private IDPWidget mIDPWidget;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_full_screen_style);

        //初始化 news 组件
        initNewsWidget();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.news_frame, mIDPWidget.getFragment())
                .commitAllowingStateLoss();
    }

    /**
     * 解决开启后台不保留活动时，将应用切到后台引起的崩溃
     *
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("android:support:fragments", null);
    }

    private void initNewsWidget() {
        mIDPWidget = DPHolder.getInstance().buildNewsTabsWidget(DPWidgetNewsParams.obtain()
                // 一定要设置代码位id，否则影响收入
                .adNewsListCodeId("945226839") // 新闻列表广告位 id
                .adNewsFirstCodeId("945226842") // 新闻详情页首卡广告位 id
                .adNewsSecondCodeId("945226844") // 新闻详情页底部广告位 id
                .adVideoFirstCodeId("945304529") // 视频详情页后贴广告位 id（自渲染）
                .adVideoSecondCodeId("945226853") // 视频详情页底部广告位 id
                .listener(new IDPNewsListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");
                    }

                    @Override
                    public void onDPNewsItemClick(Map<String, Object> map) {
                        log("onDPNewsItemClick");
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");
                    }

                    @Override
                    public void onDPNewsDetailEnter(Map<String, Object> map) {
                        log("onDPNewsDetailEnter");
                    }

                    @Override
                    public void onDPNewsDetailExit(Map<String, Object> map) {
                        log("onDPNewsDetailExit");
                    }
                }));
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
