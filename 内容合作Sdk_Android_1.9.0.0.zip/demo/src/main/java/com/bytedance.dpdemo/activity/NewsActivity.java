package com.bytedance.dpdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;

/**
 * Create by zhangxiaomin on 2020-06-12.
 */
public class NewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_news);

        findViewById(R.id.btn_news_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //新闻列表 - 全屏样式展示
                clickIntent(NewsV4FullScreenActivity.class);
            }
        });

        findViewById(R.id.btn_news_bottom_tab_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //新闻列表 - 底部 tab 样式展示
                clickIntent(NewsV4BottomTabActivity.class);
            }
        });

        findViewById(R.id.btn_news_v11_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //新闻列表 - 全屏样式 原生 Fragment 展示
                clickIntent(NewsV11FullScreenActivity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
