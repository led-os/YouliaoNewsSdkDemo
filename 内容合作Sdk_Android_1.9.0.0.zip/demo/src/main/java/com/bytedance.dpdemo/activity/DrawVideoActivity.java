package com.bytedance.dpdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;

/**
 * Create by hanweiwei on 2020-04-01.
 */
public class DrawVideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_video);

        findViewById(R.id.btn_draw_style1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频-全屏样式展示
                clickIntent(DrawVideoStyle1Activity.class);
            }
        });

        findViewById(R.id.btn_draw_style2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频-tab样式展示
                clickIntent(DrawVideoStyle2Activity.class);
            }
        });

        findViewById(R.id.btn_draw_style3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频-tab样式展示
                clickIntent(DrawVideoStyle3Activity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
