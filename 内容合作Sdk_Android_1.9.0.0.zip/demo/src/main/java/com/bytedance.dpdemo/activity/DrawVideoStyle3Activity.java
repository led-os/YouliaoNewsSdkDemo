package com.bytedance.dpdemo.activity;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetDrawParams;
import com.bytedance.sdk.dp.IDPDrawListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.Map;

/**
 * 沉浸式小视频原生fragment展示。
 * 注意不是supportV4里的fragment
 * Create by hanweiwei on 2020-04-21.
 */
public class DrawVideoStyle3Activity extends Activity {
    private static final String TAG = "DrawVideoStyle3Activity";

    private IDPWidget mIDPWidget;
    private ImageView mIvMore;
    private ImageView mIvBack;
    private RelativeLayout mTitleLayout;
    private Fragment mDrawFragment;
    private Fragment mReportFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_video_style1);

        mIvMore = findViewById(R.id.tt_iv_more);
        mIvMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mReportFragment = mIDPWidget.getReportFragment2();
                getFragmentManager().beginTransaction()
                        .add(R.id.draw_style1_frame, mReportFragment)
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
                mIvMore.setVisibility(View.GONE);
                mTitleLayout.setVisibility(View.VISIBLE);
            }
        });

        mIvBack = findViewById(R.id.tt_iv_back);
        mIvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeReport();
            }
        });

        mTitleLayout = findViewById(R.id.tt_report_title);

        //初始化draw组件
        initDrawWidget();
        mDrawFragment = mIDPWidget.getFragment2();

        getFragmentManager().beginTransaction()
                .replace(R.id.draw_style1_frame, mDrawFragment)
                .commitAllowingStateLoss();
    }

    private void initDrawWidget() {
        mIDPWidget = DPHolder.getInstance().buildDrawWidget(DPWidgetDrawParams.obtain()
                .adCodeId("945128296")//一定要设置代码位id，否则影响收入
                .hideClose(false, null)
                .listener(new IDPDrawListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");

                    }

                    @Override
                    public void onDPPageChange(int position) {
                        log("onDPPageChange: " + position);

                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");

                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");

                    }

                    @Override
                    public void onDPClose() {
                        log("onDPClose");

                    }

                    @Override
                    public void onDPReportResult(boolean isSucceed) {
                        log("onDPReportResult");
                        if (isSucceed) {
                            closeReport();
                            Toast.makeText(DrawVideoStyle3Activity.this,
                                    "举报成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(DrawVideoStyle3Activity.this,
                                    "举报失败，请稍后再试", Toast.LENGTH_SHORT).show();
                        }
                    }
                }));
    }

    private void closeReport() {
        getFragmentManager().popBackStack();
        mIvMore.setVisibility(View.VISIBLE);
        mTitleLayout.setVisibility(View.GONE);
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        closeReport();
    }
}
