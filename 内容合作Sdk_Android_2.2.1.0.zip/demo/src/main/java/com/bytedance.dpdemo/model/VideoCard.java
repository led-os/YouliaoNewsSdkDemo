package com.bytedance.dpdemo.model;

/**
 * Created by zhangxiaomin on 2020/7/21.
 */
public class VideoCard {
}
