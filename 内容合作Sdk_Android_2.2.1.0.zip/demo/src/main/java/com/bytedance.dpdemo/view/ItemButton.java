package com.bytedance.dpdemo.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bytedance.dpdemo.R;

/**
 * Create by hanweiwei on 2020/7/14.
 */
public class ItemButton extends RelativeLayout {
    /*左侧显示文本*/
    private String mLeftText;
    /*左侧图标*/
    private Drawable mLeftIcon;
    /*右侧图标*/
    private Drawable mRightIcon;
    /*左侧显示文本大小*/
    private float mLeftTextSize;
    /*左侧显示文本颜色*/
    private int mLeftTextColor;
    /*右侧显示文本大小*/
    private float mRightTextSize;
    /*右侧显示文本颜色*/
    private int mRightTextColor;
    /*左侧文本控件*/
    private TextView mTvLeftText;
    /*右侧文本控件*/
    private TextView mTvRightText;
    /*分割线*/
    private View mUnderLine, mTopLine;
    /*左侧图标控件*/
    private ImageView mIvLeftIcon;

    /*右侧图标控件,默认展示图标*/
    private ImageView mIvRightIcon;

    /*点击事件*/
    private OnClickListener mItemListener;

    public ItemButton(Context context) {
        this(context, null);
    }

    public ItemButton(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ItemButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
        initAttrs(context, attrs);

        super.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mItemListener != null) {
                    mItemListener.onClick(v);
                }
            }
        });
    }

    /**
     * 初始化自定义属性
     */
    public void initAttrs(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ItemButton);
        int n = a.getIndexCount();
        for (int i = 0; i < n; i++) {
            int attr = a.getIndex(i);
            if (attr == R.styleable.ItemButton_leftText) {
                mLeftText = a.getString(attr);
                mTvLeftText.setText(mLeftText);
            } else if (attr == R.styleable.ItemButton_leftIcon) {
                // 左侧图标
                mLeftIcon = a.getDrawable(attr);
                if (null != mLeftIcon) {
                    mIvLeftIcon.setImageDrawable(mLeftIcon);
                    mIvLeftIcon.setVisibility(VISIBLE);
                }
            } else if (attr == R.styleable.ItemButton_rightIcon) {
                // 右侧图标
                mRightIcon = a.getDrawable(attr);
                mIvRightIcon.setImageDrawable(mRightIcon);
            } else if (attr == R.styleable.ItemButton_leftTextSize) {
                // 默认设置为14sp
                mLeftTextSize = a.getFloat(attr, 14);
                mTvLeftText.setTextSize(mLeftTextSize);
            } else if (attr == R.styleable.ItemButton_leftTextColor) {
                //文字默认灰色
                mLeftTextColor = a.getColor(attr, Color.BLACK);
                mTvLeftText.setTextColor(mLeftTextColor);
            } else if (attr == R.styleable.ItemButton_isShowRightIcon) {
                //默认不显示右侧图标
                mIvRightIcon.setVisibility(a.getBoolean(attr, false) ? View.VISIBLE : View.GONE);
            } else if (attr == R.styleable.ItemButton_isShowUnderLine) {
                //默认显示分割线
                mUnderLine.setVisibility(a.getBoolean(attr, true) ? View.VISIBLE : View.GONE);
            } else if (attr == R.styleable.ItemButton_isShowTopLine) {
                //默认显示分割线
                mTopLine.setVisibility(a.getBoolean(attr, true) ? View.VISIBLE : View.GONE);
            } else if (attr == R.styleable.ItemButton_isShowRightText) {
                //默认不显示右侧文字
                mTvRightText.setVisibility(a.getBoolean(attr, false) ? View.VISIBLE : View.GONE);
            } else if (attr == R.styleable.ItemButton_rightText) {
                mTvRightText.setText(a.getString(attr));
            } else if (attr == R.styleable.ItemButton_rightTextSize) {
                // 默认设置为14sp
                mRightTextSize = a.getFloat(attr, 14);
                mTvRightText.setTextSize(mRightTextSize);
            } else if (attr == R.styleable.ItemButton_rightTextColor) {
                //文字默认灰色
                mRightTextColor = a.getColor(attr, Color.GRAY);
                mTvRightText.setTextColor(mRightTextColor);
            }
        }
        a.recycle();
    }

    private void initView(Context context) {
        View root = View.inflate(context, R.layout.view_item_button, this);

        mUnderLine = (View) root.findViewById(R.id.item_btn_underline);
        mTopLine = (View) root.findViewById(R.id.item_btn_topline);
        mTvLeftText = (TextView) root.findViewById(R.id.item_btn_tv_left_text);
        mTvRightText = (TextView) root.findViewById(R.id.item_btn_tv_right_text);
        mIvLeftIcon = (ImageView) root.findViewById(R.id.item_btn_iv_left_icon);
        mIvRightIcon = (ImageView) root.findViewById(R.id.item_btn_iv_right_icon);
    }

    @Override
    public void setOnClickListener(@Nullable OnClickListener l) {
        mItemListener = l;
    }

}