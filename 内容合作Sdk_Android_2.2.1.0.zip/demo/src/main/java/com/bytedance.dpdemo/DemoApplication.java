package com.bytedance.dpdemo;

import android.support.multidex.MultiDexApplication;

import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.dpdemo.utils.TTAdManagerHolder;

/**
 * Create by hanweiwei on 17/03/2020.
 */
public class DemoApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        //必须先初始化网盟sdk，否则可能会影响收益
        TTAdManagerHolder.init(this);

        //初始化内容合作sdk
        DPHolder.getInstance().init(this);
    }
}
