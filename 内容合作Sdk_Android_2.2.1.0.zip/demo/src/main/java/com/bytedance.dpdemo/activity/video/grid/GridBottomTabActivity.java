package com.bytedance.dpdemo.activity.video.grid;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.dpdemo.view.GridStyleOtherFragment;
import com.bytedance.sdk.dp.DPWidgetGridParams;
import com.bytedance.sdk.dp.IDPGridListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.List;
import java.util.Map;

/**
 * 底部 Tab 宫格列表样式展示
 * Create by zhangxiaomin on 2020-06-01.
 */
public class GridBottomTabActivity extends AppCompatActivity {
    public static final String TAG = GridBottomTabActivity.class.getSimpleName();
    private IDPWidget mIDPWidget;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_bottom_tab_style);

        mTabLayout = findViewById(R.id.grid_bottom_tab);
        mViewPager = findViewById(R.id.grid_view_pager);

        //初始化 grid 组件
        initGridWidget();

        //设置viewpager
        initViewPager();
    }

    private void initGridWidget() {
        mIDPWidget = DPHolder.getInstance().buildGridWidget(DPWidgetGridParams.obtain()
                .adGridCodeId("945229758")//一定要设置代码位id，否则影响收入
                .adDrawCodeId("945128296")//一定要设置代码位id，否则影响收入
                .listener(new IDPGridListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");
                    }

                    @Override
                    public void onDPGridItemClick(Map<String, Object> map) {
                        log("onDPGridItemClick");
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        log("onDPRequestSuccess");
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        log("onDPRequestFail");
                    }

                    @Override
                    public void onDPClientShow(@Nullable Map<String, Object> map) {
                        log("onDPClientShow");
                    }

                    @Override
                    public void onDPClickAuthorName(Map<String, Object> map) {
                        log("onDPClickAuthorName");
                    }

                    @Override
                    public void onDPClickAvatar(Map<String, Object> map) {
                        log("onDPClickAvatar");
                    }

                    @Override
                    public void onDPClickComment(Map<String, Object> map) {
                        log("onDPClickComment");
                    }

                    @Override
                    public void onDPClickLike(boolean isLike, Map<String, Object> map) {
                        log("onDPClickLike");
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause");
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue");
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");
                    }

                    @Override
                    public void onDPVideoCompletion(Map<String, Object> map) {
                        log("onDPVideoCompletion");
                    }
                }));
    }

    private void initViewPager() {
        final Fragment[] fragments = new Fragment[]{mIDPWidget.getFragment(), new GridStyleOtherFragment(), new GridStyleOtherFragment()};
        final String[] titles = {"首页", "消息", "我的"};
        FragmentStatePagerAdapter adapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int i) {
                return fragments[i];
            }

            @Override
            public int getCount() {
                return fragments.length;
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }

            @Override
            public Parcelable saveState() {
                return null;
            }
        };

        mViewPager.setAdapter(adapter);
        mViewPager.setOffscreenPageLimit(3);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
