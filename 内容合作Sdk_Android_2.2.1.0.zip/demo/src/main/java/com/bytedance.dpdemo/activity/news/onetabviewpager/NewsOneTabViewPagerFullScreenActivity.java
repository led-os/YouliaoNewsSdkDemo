package com.bytedance.dpdemo.activity.news.onetabviewpager;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.dpdemo.view.DrawStyleOtherFragment;
import com.bytedance.sdk.dp.DPWidgetNewsParams;
import com.bytedance.sdk.dp.IDPNewsListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.List;
import java.util.Map;

/**
 * ViewPager 嵌套单列表信息流全屏样式展示
 * Create by zhangxiaomin on 2020-09-07.
 */
public class NewsOneTabViewPagerFullScreenActivity extends AppCompatActivity {
    private static final String TAG = NewsOneTabViewPagerFullScreenActivity.class.getSimpleName();

    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private IDPWidget mIDPWidget;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_top_tab_style);

        mTabLayout = findViewById(R.id.news_top_tab);
        mViewPager = findViewById(R.id.draw_view_pager);

        //初始化 news 组件
        initNewsWidget();

        //设置 viewpager
        initViewPager();

    }

    private void initNewsWidget() {
        mIDPWidget = DPHolder.getInstance().buildNewsOneTabWidget(DPWidgetNewsParams.obtain()
                // 一定要设置代码位id，否则影响收入
                .adNewsListCodeId("945226839") // 新闻列表广告位 id
                .adNewsFirstCodeId("945226842") // 新闻详情页首卡广告位 id
                .adNewsSecondCodeId("945226844") // 新闻详情页底部广告位 id
                .adVideoFirstCodeId("945304529") // 视频详情页后贴广告位 id（自渲染）
                .adVideoSecondCodeId("945226853") // 视频详情页底部广告位 id
                .adRelatedCodeId("945334114") // 相关推荐广告位 id
                .listener(new IDPNewsListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");
                    }

                    @Override
                    public void onDPNewsItemClick(Map<String, Object> map) {
                        log("onDPNewsItemClick");
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause");
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue");
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");
                    }

                    @Override
                    public void onDPNewsDetailEnter(Map<String, Object> map) {
                        log("onDPNewsDetailEnter");
                    }

                    @Override
                    public void onDPNewsDetailExit(Map<String, Object> map) {
                        log("onDPNewsDetailExit");
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        log("onDPRequestSuccess");
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        log("onDPRequestFail");
                    }

                    @Override
                    public void onDPNewsScrollTop(@Nullable Map<String, Object> map) {
                        log("onDPNewsScrollTop");
                    }
                }));
    }

    private void initViewPager() {
        final Fragment[] fragments = new Fragment[]{mIDPWidget.getFragment(), new DrawStyleOtherFragment(), new DrawStyleOtherFragment()};
        final String[] titles = {"频道1", "频道2", "频道3"};
        FragmentStatePagerAdapter adapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int i) {
                return fragments[i];
            }

            @Override
            public int getCount() {
                return fragments.length;
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }

            @Override
            public Parcelable saveState() {
                return null;
            }
        };

        mViewPager.setAdapter(adapter);
        mViewPager.setOffscreenPageLimit(3);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public void onBackPressed() {
        if (mIDPWidget != null && !mIDPWidget.canBackPress()) {
            return;
        }

        super.onBackPressed();
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
