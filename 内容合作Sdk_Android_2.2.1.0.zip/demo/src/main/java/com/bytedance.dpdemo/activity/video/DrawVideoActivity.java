package com.bytedance.dpdemo.activity.video;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.video.draw.DrawVideoBottomTabActivity;
import com.bytedance.dpdemo.activity.video.draw.DrawVideoFullScreenV11Activity;
import com.bytedance.dpdemo.activity.video.draw.DrawVideoFullScreenActivity;
import com.bytedance.dpdemo.activity.video.draw.DrawVideoTopTabActivity;

/**
 * Create by hanweiwei on 2020-04-01.
 */
public class DrawVideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_video);

        findViewById(R.id.btn_draw_full_screen).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频 - 全屏样式展示
                clickIntent(DrawVideoFullScreenActivity.class);
            }
        });

        findViewById(R.id.btn_draw_top_tab).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频 - 顶部 tab 样式展示
                clickIntent(DrawVideoTopTabActivity.class);
            }
        });

        findViewById(R.id.btn_draw_bottom_tab).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频 - 底部 tab 样式展示
                clickIntent(DrawVideoBottomTabActivity.class);
            }
        });

        findViewById(R.id.btn_draw_frag).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //沉浸式小视频 - 系统 Fragment - 全屏样式展示
                clickIntent(DrawVideoFullScreenV11Activity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
