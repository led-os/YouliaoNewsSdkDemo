package com.bytedance.dpdemo.activity.video;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.model.Normal;
import com.bytedance.dpdemo.model.VideoCard;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetVideoCardParams;
import com.bytedance.sdk.dp.IDPElement;
import com.bytedance.sdk.dp.IDPVideoCardListener;
import com.bytedance.sdk.dp.IDPWidgetFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 小视频卡片(2.4 图） RecyclerView 样式展示
 * Create by zhangxiaomin on 2020-09-08.
 */
public class VideoCard24Activity extends AppCompatActivity {
    public static final String TAG = VideoCard24Activity.class.getSimpleName();
    private MyAdapter mAdapter;
    private RecyclerView mRecyclerView;
    private List<Object> mList = new ArrayList<>();
    private FrameLayout mVideoCardLayout;
    private IDPElement mElement;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_card_style);

        initData();
        initView();
    }

    private void initView() {
        mRecyclerView = findViewById(R.id.video_card_rv);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mAdapter = new MyAdapter(this, mList);
        mRecyclerView.setAdapter(mAdapter);
    }

    private void initData() {
        mList.add(new Normal());
        mList.add(new Normal());
        mList.add(new VideoCard());
        mList.add(new Normal());
        mList.add(new Normal());
        mList.add(new Normal());
        mList.add(new Normal());
    }

    private void loadVideoCard() {
        DPWidgetVideoCardParams params = DPWidgetVideoCardParams.obtain()
                // 一定要设置代码位id，否则影响收入
                .adVideoCardCodeId("945370200") // 小视频卡片广告位 id
                .adVideoCardInnerCodeId("945128296") // 小视频卡片内流广告位 id
                .hideTitle(false)
                .listener(new IDPVideoCardListener() {
                    @Override
                    public void onDPItemClick(Map<String, Object> map) {
                        log("onDPItemClick map = " + map.toString());
                    }

                    @Override
                    public void onDPLSwipeEnter() {
                        log("onDPLSwipeEnter");
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        if (list == null) {
                            return;
                        }

                        for (int i = 0; i < list.size(); i++) {
                            log("onDPRequestSuccess i = " + i + ", map = " + list.get(i).toString());
                        }
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        if (map == null) {
                            log("onDPRequestFail code = " + code + ", msg = " + msg);
                            return;
                        }
                        log("onDPRequestFail  code = " + code + ", msg = " + msg + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPClientShow(@Nullable Map<String, Object> map) {
                        log("onDPClientShow");
                    }

                    @Override
                    public void onDPClickAuthorName(Map<String, Object> map) {
                        log("onDPClickAuthorName map = " + map.toString());
                    }

                    @Override
                    public void onDPClickAvatar(Map<String, Object> map) {
                        log("onDPClickAvatar map = " + map.toString());
                    }

                    @Override
                    public void onDPClickComment(Map<String, Object> map) {
                        log("onDPClickComment map = " + map.toString());
                    }

                    @Override
                    public void onDPClickLike(boolean isLike, Map<String, Object> map) {
                        log("onDPClickLike isLike = " + isLike + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoCompletion(Map<String, Object> map) {
                        log("onDPVideoCompletion map = " + map.toString());
                    }
                })
                .dislikeListener(this, new DPWidgetVideoCardParams.IDislikeListener() {
                    @Override
                    public void onSelected(String msg) {
                        // 如果 hideTitle 为 true，可以不做任何处理
                        log("dislike msg = " + msg);
                        if (mVideoCardLayout == null) {
                            return;
                        }
                        mVideoCardLayout.removeAllViews();
                        mVideoCardLayout.setVisibility(View.GONE);
                    }
                });

        DPHolder.getInstance().loadSmallVideoCard(params, new IDPWidgetFactory.Callback() {
            @Override
            public void onError(int code, String msg) {
                log("onError code = " + code + ", msg = " + msg);
            }

            @Override
            public void onSuccess(IDPElement data) {
                mElement = data;
                View view = data.getView();
                if (view == null || mVideoCardLayout == null) {
                    return;
                }

                mVideoCardLayout.removeAllViews();
                ViewGroup viewGroup = (ViewGroup) view.getParent();
                if (viewGroup != null) {
                    viewGroup.removeAllViews();
                }
                mVideoCardLayout.addView(view);
            }
        });
    }

    private class MyAdapter extends RecyclerView.Adapter {
        private static final int ITEM_VIEW_TYPE_NORMAL = 1;
        private static final int ITEM_VIEW_TYPE_VIDEO_CARD = 2;

        private List<Object> mData;
        private Context mContext;

        public MyAdapter(Context context, List<Object> data) {
            this.mContext = context;
            this.mData = data;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            switch (viewType) {
                case ITEM_VIEW_TYPE_VIDEO_CARD:
                    // 加载 video card 组件
                    loadVideoCard();
                    return new VideoCardHolder(LayoutInflater.from(mContext).inflate(R.layout.item_video_card, parent, false));
                default:
                    return new NormalViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_normal, parent, false));
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof NormalViewHolder) {
                ((NormalViewHolder) holder).itemText.setText("item " + position);
            } else if (holder instanceof VideoCardHolder) {
                mVideoCardLayout = ((VideoCardHolder) holder).frameLayout;
            }
        }

        @Override
        public int getItemCount() {
            return mData == null ? 0 : mData.size();
        }

        @Override
        public int getItemViewType(int position) {
            if (mData != null) {
                Object object = mData.get(position);
                if (object instanceof Normal) {
                    return ITEM_VIEW_TYPE_NORMAL;
                } else if (object instanceof VideoCard) {
                    return ITEM_VIEW_TYPE_VIDEO_CARD;
                }
            }

            return super.getItemViewType(position);
        }

        public void remove(int position) {
            mList.remove(position);
            notifyItemRemoved(position);

            // 如果移除的是最后一个，忽略
            if (position != (mList.size())) {
                notifyItemRangeChanged(position, mList.size() - position);
            }
        }

        private class VideoCardHolder extends RecyclerView.ViewHolder {
            FrameLayout frameLayout;

            public VideoCardHolder(View itemView) {
                super(itemView);
                frameLayout = itemView.findViewById(R.id.video_card_item);
            }
        }

        private class NormalViewHolder extends RecyclerView.ViewHolder {
            TextView itemText;

            public NormalViewHolder(View itemView) {
                super(itemView);
                itemText = (TextView) itemView.findViewById(R.id.item_text);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mElement != null) {
            mElement.destroy();
        }
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
