package com.bytedance.dpdemo.activity.video.draw;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetDrawParams;
import com.bytedance.sdk.dp.IDPDrawListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.List;
import java.util.Map;

/**
 * 沉浸式小视频场景展示：全屏样式
 * Create by hanweiwei on 2020-04-21.
 */
public class DrawVideoFullScreenActivity extends AppCompatActivity {
    private static final String TAG = DrawVideoFullScreenActivity.class.getSimpleName();

    private ImageView mImgReport;
    private IDPWidget mIDPWidget;
    private Fragment mDrawFragment;
    private Fragment mReportFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_video_full_screen);

        mImgReport = findViewById(R.id.draw_style1_report);
        mImgReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mReportFragment = mIDPWidget.getReportFragment();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.draw_style1_frame2, mReportFragment)
                        .commitAllowingStateLoss();
                mImgReport.setVisibility(View.GONE);
            }
        });

        //初始化draw组件
        initDrawWidget();
        mDrawFragment = mIDPWidget.getFragment();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.draw_style1_frame, mDrawFragment)
                .commitAllowingStateLoss();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("android:support:fragments", null);
    }

    private void initDrawWidget() {
        mIDPWidget = DPHolder.getInstance().buildDrawWidget(DPWidgetDrawParams.obtain()
                .adCodeId("945128296")//一定要设置代码位id，否则影响收入
                .adOffset(0) //单位 dp，为 0 时可以不设置
                .hideClose(false, null)
                .listener(new IDPDrawListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");

                    }

                    @Override
                    public void onDPPageChange(int position) {
                        log("onDPPageChange: " + position);

                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay map = " + map.toString());

                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver map = " + map.toString());

                    }

                    @Override
                    public void onDPVideoCompletion(Map<String, Object> map) {
                        log("onDPVideoCompletion map = " + map.toString());

                    }

                    @Override
                    public void onDPClose() {
                        log("onDPClose");

                    }

                    @Override
                    public void onDPReportResult(boolean isSucceed) {
                        log("onDPReportResult isSucceed = " + isSucceed);
                    }

                    @Override
                    public void onDPReportResult(boolean isSucceed, Map<String, Object> map) {
                        if (isSucceed) {
                            closeReport();
                        }
                        log("onDPReportResult isSucceed = " + isSucceed + ", map = " + map.toString());
                        if (isSucceed) {
                            Toast.makeText(DrawVideoFullScreenActivity.this,
                                    "举报成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(DrawVideoFullScreenActivity.this,
                                    "举报失败，请稍后再试", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        if (list == null) {
                            return;
                        }

                        for (int i = 0; i < list.size(); i++) {
                            log("onDPRequestSuccess i = " + i + ", map = " + list.get(i).toString());
                        }
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        if (map == null) {
                            log("onDPRequestFail code = " + code + ", msg = " + msg);
                            return;
                        }
                        log("onDPRequestFail  code = " + code + ", msg = " + msg + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPClickAuthorName(Map<String, Object> map) {
                        log("onDPClickAuthorName map = " + map.toString());
                    }

                    @Override
                    public void onDPClickAvatar(Map<String, Object> map) {
                        log("onDPClickAvatar map = " + map.toString());
                    }

                    @Override
                    public void onDPClickComment(Map<String, Object> map) {
                        log("onDPClickComment map = " + map.toString());
                    }

                    @Override
                    public void onDPClickLike(boolean isLike, Map<String, Object> map) {
                        log("onDPClickLike isLike = " + isLike + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue map = " + map.toString());
                    }
                }));
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }

    private boolean closeReport() {
        if (mReportFragment != null) {
            mImgReport.setVisibility(View.VISIBLE);
            getSupportFragmentManager().beginTransaction()
                    .remove(mReportFragment)
                    .commitAllowingStateLoss();
            mReportFragment = null;
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if (closeReport()) {
            return;
        }
        if (mIDPWidget != null && !mIDPWidget.canBackPress()) {
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mIDPWidget != null) {
            mIDPWidget.destroy();
        }
    }
}
