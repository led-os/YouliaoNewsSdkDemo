package com.bytedance.dpdemo.activity.video;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetVideoSingleCardParams;
import com.bytedance.sdk.dp.IDPElement;
import com.bytedance.sdk.dp.IDPVideoSingleCardListener;
import com.bytedance.sdk.dp.IDPWidgetFactory;

import java.util.List;
import java.util.Map;

/**
 * 小视频单卡片（信息流）样式展示
 * Create by zhangxiaomin on 2020-09-14.
 */
public class VideoCardNewsActivity extends AppCompatActivity {
    public static final String TAG = VideoCardNewsActivity.class.getSimpleName();
    private FrameLayout mVideoCardLayout;
    private IDPElement mElement;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_card_single_news_style);

        initView();
        loadVideoCard();
    }

    private void initView() {
        mVideoCardLayout = findViewById(R.id.video_single_card_news_layout);
    }

    private void loadVideoCard() {
        DPWidgetVideoSingleCardParams params = DPWidgetVideoSingleCardParams.obtain()
                // 一定要设置代码位id，否则影响收入
                .adVideoCardInnerCodeId("945128296") // 小视频单卡片内流广告位 id
                .hidePlay(false) //隐藏播放按钮
                .hideTitle(false) //隐藏标题
                .hideBottomInfo(false) //隐藏底部信息
                .listener(new IDPVideoSingleCardListener() {
                    @Override
                    public void onDPClick(Map<String, Object> map) {
                        log("onDPClick map = " + map.toString());
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        if (list == null) {
                            return;
                        }

                        for (int i = 0; i < list.size(); i++) {
                            log("onDPRequestSuccess i = " + i + ", map = " + list.get(i).toString());
                        }
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        if (map == null) {
                            log("onDPRequestFail code = " + code + ", msg = " + msg);
                            return;
                        }
                        log("onDPRequestFail  code = " + code + ", msg = " + msg + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPClientShow(Map<String, Object> map) {
                        log("onDPClientShow map = " + map.toString());
                    }

                    @Override
                    public void onDPClickAuthorName(Map<String, Object> map) {
                        log("onDPClickAuthorName map = " + map.toString());
                    }

                    @Override
                    public void onDPClickAvatar(Map<String, Object> map) {
                        log("onDPClickAvatar map = " + map.toString());
                    }

                    @Override
                    public void onDPClickComment(Map<String, Object> map) {
                        log("onDPClickComment map = " + map.toString());
                    }

                    @Override
                    public void onDPClickLike(boolean isLike, Map<String, Object> map) {
                        log("onDPClickLike isLike = " + isLike + ", map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver map = " + map.toString());
                    }

                    @Override
                    public void onDPVideoCompletion(Map<String, Object> map) {
                        log("onDPVideoCompletion map = " + map.toString());
                    }
                });

        DPHolder.getInstance().loadVideoSingleCard4News(params, new IDPWidgetFactory.Callback() {
            @Override
            public void onError(int code, String msg) {
                log("onError code = " + code + ", msg = " + msg);
            }

            @Override
            public void onSuccess(IDPElement data) {
                if (data == null) {
                    return;
                }

                mElement = data;
                View view = data.getView();
                log("title = " + data.getTitle()); //获取标题
                if (view == null || mVideoCardLayout == null) {
                    return;
                }

                mVideoCardLayout.removeAllViews();
                ViewGroup viewGroup = (ViewGroup) view.getParent();
                if (viewGroup != null) {
                    viewGroup.removeAllViews();
                }
                mVideoCardLayout.addView(view);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mElement != null) {
            mElement.destroy();
        }
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
