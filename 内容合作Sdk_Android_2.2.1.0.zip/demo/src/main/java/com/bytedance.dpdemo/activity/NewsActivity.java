package com.bytedance.dpdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.news.NewsOneTabActivity;
import com.bytedance.dpdemo.activity.news.NewsOneTabViewPagerActivity;
import com.bytedance.dpdemo.activity.news.NewsTabsActivity;

/**
 * Create by zhangxiaomin on 2020-06-12.
 */
public class NewsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_news);

        findViewById(R.id.btn_tabs_news).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(NewsTabsActivity.class);
            }
        });

        findViewById(R.id.btn_one_tab_news).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(NewsOneTabActivity.class);
            }
        });

        findViewById(R.id.btn_view_pager_news).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(NewsOneTabViewPagerActivity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
