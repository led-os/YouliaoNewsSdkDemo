package com.bytedance.dpdemo.activity.news;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.news.onetabviewpager.NewsOneTabViewPagerBottomTabActivity;
import com.bytedance.dpdemo.activity.news.onetabviewpager.NewsOneTabViewPagerFullScreenActivity;

/**
 * Create by zhangxiaomin on 2020-09-20.
 */
public class NewsOneTabViewPagerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_news_one_tab_view_pager);

        findViewById(R.id.btn_news_one_tab_view_pager_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ViewPager 嵌套单列表 - 信息流 - 全屏样式展示
                clickIntent(NewsOneTabViewPagerFullScreenActivity.class);
            }
        });

        findViewById(R.id.btn_news_one_tab_view_pager_bottom_tab_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ViewPager 嵌套单列表 - 信息流 - 底部 tab 样式展示
                clickIntent(NewsOneTabViewPagerBottomTabActivity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
