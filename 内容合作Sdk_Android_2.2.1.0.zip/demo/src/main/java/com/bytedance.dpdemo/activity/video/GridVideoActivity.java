package com.bytedance.dpdemo.activity.video;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.video.grid.GridBottomTabActivity;
import com.bytedance.dpdemo.activity.video.grid.GridFullScreenV11Activity;
import com.bytedance.dpdemo.activity.video.grid.GridFullScreenActivity;
import com.bytedance.dpdemo.activity.video.grid.GridTopTabActivity;

/**
 * Create by hanweiwei on 2020-05-15.
 */
public class GridVideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_grid);

        findViewById(R.id.btn_grid_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //宫格列表 - 全屏样式展示
                clickIntent(GridFullScreenActivity.class);
            }
        });

        findViewById(R.id.btn_grid_top_tab_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //宫格列表 - 顶部 tab 样式展示
                clickIntent(GridTopTabActivity.class);
            }
        });

        findViewById(R.id.btn_grid_bottom_tab_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //宫格列表 - 底部 tab 样式展示
                clickIntent(GridBottomTabActivity.class);
            }
        });

        findViewById(R.id.btn_grid_frag_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //宫格列表 - 系统 Fragment 全屏样式展示
                clickIntent(GridFullScreenV11Activity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
