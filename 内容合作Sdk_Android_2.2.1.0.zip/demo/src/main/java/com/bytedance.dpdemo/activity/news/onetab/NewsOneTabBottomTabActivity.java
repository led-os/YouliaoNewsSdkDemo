package com.bytedance.dpdemo.activity.news.onetab;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.dpdemo.view.NewsStyleOtherFragment;
import com.bytedance.sdk.dp.DPWidgetNewsParams;
import com.bytedance.sdk.dp.IDPNewsListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.List;
import java.util.Map;

/**
 * 单列表信息流底部 Tab 样式展示
 * Create by zhangxiaomin on 2020-09-07.
 */
public class NewsOneTabBottomTabActivity extends AppCompatActivity {
    public static final String TAG = NewsOneTabBottomTabActivity.class.getSimpleName();
    private IDPWidget mIDPWidget;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_bottom_tab_style);

        mTabLayout = findViewById(R.id.news_bottom_tab);
        mViewPager = findViewById(R.id.news_view_pager);

        //初始化 news 组件
        initNewsWidget();

        //设置viewpager
        initViewPager();
    }

    /**
     * 解决开启后台不保留活动时，将应用切到后台引起的崩溃
     *
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("android:support:fragments", null);
    }

    private void initNewsWidget() {
        mIDPWidget = DPHolder.getInstance().buildNewsOneTabWidget(DPWidgetNewsParams.obtain()
                // 一定要设置代码位id，否则影响收入
                .adNewsListCodeId("945226839") // 新闻列表广告位 id
                .adNewsFirstCodeId("945226842") // 新闻详情页首卡广告位 id
                .adNewsSecondCodeId("945226844") // 新闻详情页底部广告位 id
                .adVideoFirstCodeId("945304529") // 视频详情页后贴广告位 id（自渲染）
                .adVideoSecondCodeId("945226853") // 视频详情页底部广告位 id
                .adRelatedCodeId("945334114") // 相关推荐广告位 id
                .listener(new IDPNewsListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");
                    }

                    @Override
                    public void onDPNewsItemClick(Map<String, Object> map) {
                        log("onDPNewsItemClick");
                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause");
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue");
                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");
                    }

                    @Override
                    public void onDPNewsDetailEnter(Map<String, Object> map) {
                        log("onDPNewsDetailEnter");
                    }

                    @Override
                    public void onDPNewsDetailExit(Map<String, Object> map) {
                        log("onDPNewsDetailExit");
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        log("onDPRequestSuccess");
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        log("onDPRequestFail");
                    }

                    @Override
                    public void onDPNewsScrollTop(@Nullable Map<String, Object> map) {
                        log("onDPNewsScrollTop");
                    }
                }));
    }

    private void initViewPager() {
        final Fragment[] fragments = new Fragment[]{mIDPWidget.getFragment(), new NewsStyleOtherFragment(), new NewsStyleOtherFragment()};
        final String[] titles = {"首页", "消息", "我的"};
        FragmentStatePagerAdapter adapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int i) {
                return fragments[i];
            }

            @Override
            public int getCount() {
                return fragments.length;
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }

            @Override
            public Parcelable saveState() {
                return null;
            }
        };

        mViewPager.setAdapter(adapter);
        mViewPager.setOffscreenPageLimit(3);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
