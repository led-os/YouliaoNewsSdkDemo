package com.bytedance.dpdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.video.GridVideoActivity;
import com.bytedance.dpdemo.activity.video.DrawVideoActivity;
import com.bytedance.dpdemo.activity.video.VideoCard24Activity;
import com.bytedance.dpdemo.activity.video.VideoCard14Activity;
import com.bytedance.dpdemo.activity.video.VideoCardDialogActivity;
import com.bytedance.dpdemo.activity.video.VideoCardNewsActivity;

/**
 * Created by zhangxiaomin on 2020/9/9.
 */
public class VideoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        findViewById(R.id.btn_draw_video).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(DrawVideoActivity.class);
            }
        });

        findViewById(R.id.btn_grid_video).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(GridVideoActivity.class);
            }
        });

        findViewById(R.id.btn_video_card_dialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(VideoCardDialogActivity.class);
            }
        });

        findViewById(R.id.btn_video_card_news).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(VideoCardNewsActivity.class);
            }
        });

        findViewById(R.id.btn_video_card_14).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(VideoCard14Activity.class);
            }
        });

        findViewById(R.id.btn_video_card_24).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickIntent(VideoCard24Activity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
