package com.bytedance.dpdemo.activity.news.onetabviewpager;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.view.NewsStyleOtherFragment;
import com.bytedance.dpdemo.view.NewsViewPagerFragment;

/**
 * ViewPager 嵌套单列表信息流底部 Tab 样式展示
 * Create by zhangxiaomin on 2020-09-16.
 */
public class NewsOneTabViewPagerBottomTabActivity extends AppCompatActivity {
    public static final String TAG = NewsOneTabViewPagerBottomTabActivity.class.getSimpleName();
    private TabLayout mTabLayout;
    private ViewPager mViewPager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_bottom_tab_view_pager_style);

        mTabLayout = findViewById(R.id.news_bottom_tab);
        mViewPager = findViewById(R.id.news_view_pager);

        //设置viewpager
        initViewPager();
    }

    /**
     * 解决开启后台不保留活动时，将应用切到后台引起的崩溃
     *
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("android:support:fragments", null);
    }

    private void initViewPager() {
        final Fragment[] fragments = new Fragment[]{new NewsViewPagerFragment(), new NewsStyleOtherFragment(), new NewsStyleOtherFragment()};
        final String[] titles = {"首页", "消息", "我的"};
        FragmentStatePagerAdapter adapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int i) {
                return fragments[i];
            }

            @Override
            public int getCount() {
                return fragments.length;
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }

            @Override
            public Parcelable saveState() {
                return null;
            }
        };

        mViewPager.setAdapter(adapter);
        mViewPager.setOffscreenPageLimit(3);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }
}
