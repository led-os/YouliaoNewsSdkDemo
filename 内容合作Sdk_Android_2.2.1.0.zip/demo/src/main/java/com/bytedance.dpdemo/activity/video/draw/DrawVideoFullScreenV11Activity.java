package com.bytedance.dpdemo.activity.video.draw;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.utils.DPHolder;
import com.bytedance.sdk.dp.DPWidgetDrawParams;
import com.bytedance.sdk.dp.IDPDrawListener;
import com.bytedance.sdk.dp.IDPWidget;

import java.util.List;
import java.util.Map;

/**
 * 沉浸式小视频原生 fragment 展示。
 * 注意不是 supportV4 里的 fragment
 * Create by hanweiwei on 2020-04-21.
 */
public class DrawVideoFullScreenV11Activity extends Activity {
    private static final String TAG = DrawVideoFullScreenV11Activity.class.getSimpleName();

    private ImageView mImgReport;
    private IDPWidget mIDPWidget;
    private Fragment mDrawFragment;
    private Fragment mReportFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_video_full_screen);

        mImgReport = findViewById(R.id.draw_style1_report);
        mImgReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mReportFragment = mIDPWidget.getReportFragment2();
                getFragmentManager().beginTransaction()
                        .replace(R.id.draw_style1_frame2, mReportFragment)
                        .commitAllowingStateLoss();
                mImgReport.setVisibility(View.GONE);
            }
        });

        //初始化draw组件
        initDrawWidget();
        mDrawFragment = mIDPWidget.getFragment2();

        getFragmentManager().beginTransaction()
                .replace(R.id.draw_style1_frame, mDrawFragment)
                .commitAllowingStateLoss();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("android:fragments", null);
    }

    private void initDrawWidget() {
        mIDPWidget = DPHolder.getInstance().buildDrawWidget(DPWidgetDrawParams.obtain()
                .adCodeId("945128296")//一定要设置代码位id，否则影响收入
                .adOffset(0) //单位 dp，为 0 时可以不设置
                .hideClose(false, null)
                .listener(new IDPDrawListener() {
                    @Override
                    public void onDPRefreshFinish() {
                        log("onDPRefreshFinish");

                    }

                    @Override
                    public void onDPPageChange(int position) {
                        log("onDPPageChange: " + position);

                    }

                    @Override
                    public void onDPVideoPlay(Map<String, Object> map) {
                        log("onDPVideoPlay");

                    }

                    @Override
                    public void onDPVideoCompletion(Map<String, Object> map) {
                        log("onDPVideoCompletion: ");

                    }

                    @Override
                    public void onDPVideoOver(Map<String, Object> map) {
                        log("onDPVideoOver");

                    }

                    @Override
                    public void onDPClose() {
                        log("onDPClose");

                    }

                    @Override
                    public void onDPReportResult(boolean isSucceed) {
                        log("onDPReportResult");
                    }

                    @Override
                    public void onDPReportResult(boolean isSucceed, Map<String, Object> map) {
                        if (isSucceed) {
                            closeReport();
                        }
                        log("onDPReportResult");
                        if (isSucceed) {
                            Toast.makeText(DrawVideoFullScreenV11Activity.this,
                                    "举报成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(DrawVideoFullScreenV11Activity.this,
                                    "举报失败，请稍后再试", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onDPRequestStart(@Nullable Map<String, Object> map) {
                        log("onDPRequestStart");
                    }

                    @Override
                    public void onDPRequestSuccess(List<Map<String, Object>> list) {
                        log("onDPRequestSuccess");
                    }

                    @Override
                    public void onDPRequestFail(int code, String msg, @Nullable Map<String, Object> map) {
                        log("onDPRequestFail");
                    }

                    @Override
                    public void onDPClickAuthorName(Map<String, Object> map) {
                        log("onDPClickAuthorName");
                    }

                    @Override
                    public void onDPClickAvatar(Map<String, Object> map) {
                        log("onDPClickAvatar");
                    }

                    @Override
                    public void onDPClickComment(Map<String, Object> map) {
                        log("onDPClickComment");
                    }

                    @Override
                    public void onDPClickLike(boolean isLike, Map<String, Object> map) {
                        log("onDPClickLike");
                    }

                    @Override
                    public void onDPVideoPause(Map<String, Object> map) {
                        log("onDPVideoPause");
                    }

                    @Override
                    public void onDPVideoContinue(Map<String, Object> map) {
                        log("onDPVideoContinue");
                    }
                }));
    }

    private static void log(String msg) {
        Log.d(TAG, String.valueOf(msg));
    }

    private boolean closeReport() {
        if (mReportFragment != null) {
            mImgReport.setVisibility(View.VISIBLE);
            getFragmentManager().beginTransaction()
                    .remove(mReportFragment)
                    .commitAllowingStateLoss();
            mReportFragment = null;
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if (closeReport()) {
            return;
        }
        if (mIDPWidget != null && !mIDPWidget.canBackPress()) {
            return;
        }

        super.onBackPressed();
    }
}
