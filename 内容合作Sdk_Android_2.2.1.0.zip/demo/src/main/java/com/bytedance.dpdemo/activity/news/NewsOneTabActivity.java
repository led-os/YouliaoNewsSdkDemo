package com.bytedance.dpdemo.activity.news;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bytedance.dpdemo.R;
import com.bytedance.dpdemo.activity.news.onetab.NewsOneTabBottomTabActivity;
import com.bytedance.dpdemo.activity.news.onetab.NewsOneTabFullScreenActivity;
import com.bytedance.dpdemo.activity.news.onetab.NewsOneTabFullScreenV11Activity;

/**
 * Create by zhangxiaomin on 2020-09-09.
 */
public class NewsOneTabActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_news_one_tab);

        findViewById(R.id.btn_news_one_tab_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 单列表 - 信息流 - 全屏样式展示
                clickIntent(NewsOneTabFullScreenActivity.class);
            }
        });

        findViewById(R.id.btn_news_one_tab_bottom_tab_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 单列表 - 信息流 - 底部 tab 样式展示
                clickIntent(NewsOneTabBottomTabActivity.class);
            }
        });

        findViewById(R.id.btn_news_v11_one_tab_full_screen_style).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 单列表 - 信息流 - 全屏样式 原生 Fragment 展示
                clickIntent(NewsOneTabFullScreenV11Activity.class);
            }
        });
    }

    private void clickIntent(Class cls) {
        Intent intent = new Intent(this, cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
