//package com.bytedance.dpdemo.utils;
//
//import android.content.Context;
//
//import com.bykv.vk.openvk.TTVfConfig;
//import com.bykv.vk.openvk.TTVfConstant;
//import com.bykv.vk.openvk.TTVfManager;
//import com.bykv.vk.openvk.TTVfSdk;
//import com.bytedance.dpdemo.R;
//
///**
// * 穿山甲 oppo 定制版（3110） sdk 初始化
// */
//public class TTVfManagerHolder {
//
//    private static boolean sInit;
//
//
//    public static TTVfManager get() {
//        if (!sInit) {
//            throw new RuntimeException("TTObSdk is not init, please check.");
//        }
//        return TTVfSdk.getVfManager();
//    }
//
//    public static void init(Context context) {
//        doInit(context);
//    }
//
//    //step1:接入网盟广告sdk的初始化操作，详情见接入文档和穿山甲平台说明
//    private static void doInit(Context context) {
//        if (!sInit) {
//            TTVfSdk.init(context, buildConfig(context));
//            sInit = true;
//        }
//    }
//
//    private static TTVfConfig buildConfig(Context context) {
//        return new TTVfConfig.Builder()
//                .appId("5059538")
//                .appName(context.getString(R.string.app_name))
//                .titleBarTheme(TTVfConstant.TITLE_BAR_THEME_DARK)
//                .useTextureView(true)
//                .allowShowNotify(true) //是否允许sdk展示通知栏提示
//                .allowShowPageWhenScreenLock(true) //是否在锁屏场景支持展示广告落地页
//                .debug(true) //测试阶段打开，可以通过日志排查问题，上线时去除该调用
//                .build();
//    }
//}
